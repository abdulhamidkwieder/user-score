document.addEventListener("deviceready", function() {
  console.log("deviceready");
  gyroscope.getCurrent(function() {
    console.log(argument);
  });
});
