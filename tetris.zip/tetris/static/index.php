<?php 
require_once 'misc/init.php';
require_once 'layout/head.php';

// Setzt page auf default falls nicht vorhanden
$site = $_GET['page'] ?? "default";

?>

</head>
<body>

  <?php 
  // Läd Menüleiste
  require_once 'layout/nav-bar.php'; 
  ?>
<header class="container header">
  <br>
  <h1>Sind Sie bereit zu spielen?</h1>
  <br>
</header>
<main class="container">
<div class="row">
  <div class="col-auto mr-auto">
  <!-- Contentplace -->
  </div>
    <div class="col-8">
      <?php

      /**
       * Prüft den Sessionlogin
       * Wenn True, startet das Spiel
       * Wenn False, wird $_GET geprüft ob der page Key gesetzt ist und ob dieser auf register steht
       * Ist dies der Fall, wird das Registrierungsformular aufgerufen
       * Sind beide Optionen falsch, wird der Login angezeigt
       */
      if ($user->loggedIn($_SESSION) === true){
        if (array_key_exists('page', $_GET)) {
          switch ($_GET['page']) {
            case 'game': 
              require_once 'misc/game.php';
              break;
            case 'highscore':
              require_once 'misc/highscore';
              break;
  
            default:
              require_once 'misc/login-welcome.php';
              
            }
          } else {
            require_once 'misc/login-welcome.php';

          }
      } 
      elseif (array_key_exists('page' , $_GET) && $_GET['page'] === 'register'){
        require_once 'misc/register.php';

      // TODO: Session wird erst auf True gesetzt wenn die Seite aktualisiert wird
      // Falsche Reihenfolge vom Scriptloading? 
      } else {
        require_once 'misc/login.php';

      }
      ?>
    </div>
  <div class="col-auto mr-auto">
  <!-- Contentplace -->
  </div>
</div>
</main>

  <?php 
  require_once 'layout/footer.php';
  ?>
