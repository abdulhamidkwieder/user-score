<?php

class SpiderForms {
    protected $name;
    protected $type;
    protected $id;
    protected $attributes = [];

    public function __construct(array $config) {
        $this->name = $config['name'];
        $this->type = $config['type'];
        $this->id = $config['id'];
        $this->label = $config['label'];
        
        if (array_key_exists('attributes' , $config) && is_array($config['attributes']) && !empty($config['attributes'])){
            $this->attributes = ['attributes'];
        }
    }


    public function render() {
        $out = '';
        $out .= $this->renderLabel();
        $out .= $this->renderField();
        return $out;
    }


    public function renderLabel(){
        // <label for="config eingetragene ID">config eingetragenes Label</label>
        $out = '';
        $out .= '<label for="' . $this->id . '" >';
        $out .= $this->label;
        $out .= '</label>';
        return $out;
    }

    // <input type="text" id="config ID" name="config name">
    public function renderField() {
        $out = '';
        $out .= '<input type="' . $this->type . '" ';
        $out .= 'id="' . $this->id . '" ';
        $out .= 'name="' . $this->name . '" ';
        $out .= $this->renderAttributes();
        return $out;
    }

    /**
     * TODO: FIX THIS FUNCTION
     */
    protected function renderAttributes() {
        $out = '';
        $delimiter = '';
        foreach($this->attributes as $name => $val) {
            $out .= $delimiter . $name . '="' . $val . '"';
            $delimiter = ' ';
        }
        return $out;
    }
}