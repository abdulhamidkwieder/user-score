<?php
class SpiderstrapForms {
    protected $name;
    protected $type;
    protected $id;
    protected $config = [];
    protected $username;
    protected $password;
    protected $register = [];


    /**
     * Spiderstrap erstellt fertige Formulare mit Basis von Bootstrap
     *  
     *  Ein Array wird in login und register getrennt
     *  Es müssen nicht beide definiert werden, jedoch muss der Login 'username' und 'password' als Key enthalten
     *  Außerdem haben alle Felder 'name', 'type', 'id' und 'label'
     *  Diese müssen zumindest mit einem Leerstring '' definiert werden
     */
    public function __construct(array $config){

        $this->config = $config;

        if (array_key_exists('login', $config)){        
            if (array_key_exists('username', $config['login']) && array_key_exists('password', $config['login'])){
                    $this->username = $config['login']['username'];
                    $this->password = $config['login']['password'];
                }
            }
        if (array_key_exists('register' , $config)) {
            $this->register = $config['register'];
        }
    }

    /**
     * Gibt einen feritgen Login Handler zurück
     */
    public function renderLogin(){
        $out = '';
        $out .= '<form class="px-4 py-3" action="" method="post">'.
                '<div class="form-group">'.
                $this->renderLabel($this->username).
                $this->renderInput($this->username).
                '</div><div class="form-group">'.
                $this->renderLabel($this->password).
                $this->renderInput($this->password).
                '</div><button type="submit" class="btn btn-primary">Login</button></form>';
        
        return $out;
    }

    /**
     * Gibt einen fertigen Register Handler zurück
     * Achtung!
     * Ausgabe ist ein Array!
     */
    public function renderRegister() {
        $counter = 0;
        $out = '';


        foreach ($this->register AS $key => $val){
            $counter++;
            if ($counter === 1){
                $out = '<form class="px-4 py-3" action="" method="post">'.
                        '<div class="form-group">';
            }

            $out = $this->renderLabel($this->register[$key]);
            $out .= $this->renderInput($this->register[$key]);
            if ($counter === count($this->register)) {
                $out .= '<div class="form-group">'.
                '<div class="form-check">'.
                '<input class="form-check-input" type="checkbox" id="gridCheck">'.
                '<label class="form-check-label" for="gridCheck">'.
                'Check me out'.
                '</label></div></div>'.
                '<button type="submit" class="btn btn-primary">Registrieren</button></div></form>';
            }

            yield $out;
        }        
    }

    /**
     * Gibt die letzte Fehlermeldung aus einem Array in einer 'alert-danger' Karte zurück
     * via echo eine kompakte Fehlermeldung
     */
    public function errorHandlerArray(array $val) {
        $out = '';
        if (!empty($val)) {
            foreach ($val AS $row){
                $out .= '<div class="alert alert-danger" role="alert">' . 
                        $row . '</div>';
            }
        }
        return $out;
    }

    public function renderLabel($val){
        $out = '';
        $out .= '<label for="' . $val['id'] . '" >'.
                $val['label'].
                '</label>';
        return $out;
    }

    public function renderInput($val) {
        $out = '';
        $out .= '<input type="' . $val['type'] . '" '.
                'id="' . $val['id'] . '" '.
                'name="' . $val['name'] . '" class="form-control"> ';
        return $out;
    }    
}