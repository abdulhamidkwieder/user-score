<div class="container">
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <a class="navbar-brand" href="index.php">Tetris</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarText" aria-controls="navbarText" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <?php if ($user->loggedIn($_SESSION)): ?>
        <div class="collapse navbar-collapse" id="navbarText">
            <ul class="navbar-nav mr-auto">
                <li class="nav-item active">
                    <a class="nav-link" href="index.php?page=game">Zum Spiel</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="index.php?page=highscore">Mein Highscore</a>
                </li>
            </ul>
        </div>
        <?php else: ?>
        <div class="collapse navbar-collapse" id="navbarText">
            <ul class="navbar-nav mr-auto">
                <li class="nav-item active">
                    <a class="nav-link" href="index.php">Einloggen</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="index.php?page=register">Registrieren</a>
                </li>
            </ul>
        </div>
        <?php endif; ?>
    </nav>
</div>