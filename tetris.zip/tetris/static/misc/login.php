<div class="card">
    <div class="card-body">
        <h5 class="card-title">
            Bitte loggen Sie sich ein
        </h5>
        <?php 
        require_once 'misc/check-login.php';

        // $bootstrap ist ein new SpiderstrapForms($formConfig) und in der init vordefiniert
        // Im errorHandlerArray werden die Fehler ausgegeben die von $errors aus der check-login.php ankommen
        // errorHandlerArray ist teil von SpiderstrapForms und gibt Fehlermeldungen mit Bootstrap-Alert-Class aus
        echo $bootstrap->errorHandlerArray($errors);

        // renderLogin wird in der formConfig definiert
        echo $bootstrap->renderLogin();
        ?>
    </div>
</div> 

