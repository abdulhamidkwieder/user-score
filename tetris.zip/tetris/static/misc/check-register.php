<?php
// post prüfen
$errors = [];
if (!empty($_POST)) {
    $gump = new GUMP('de');

    // Validierungen bekannt geben
    $gump->validation_rules(
        [
            'username' => 'required|min_len,3|max_len,255',
            'password' => 'required|min_len,8|max_len,255',
            'email' => 'required|valid_email'
        ]
    );

    $validData = $gump->run($_POST);


    if ($_POST['password'] !== $_POST['passConfirm']) {
        $validData = false;
        $errors['confirm'] = 'Bitte füllen Sie dieses Feld aus.';
    }
   
    if ($validData === false) {
        // Fehler ausgeben
        // String mit den Fehlern.
        $errors['gumpError'] = $gump->get_readable_errors(true);
        // Name Value Pairs zu feldern mit den Fehlern
    }
    else {
        $user->register($_POST['username'], $_POST['password'] , $_POST['email']);
    }
 
}