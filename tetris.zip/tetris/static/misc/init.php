<?php

// TODO: Autoloader
require_once 'SpiderLib/SpiderDB.php';
require_once 'SpiderLib/SpiderUser.php';
require_once 'SpiderLib/SpiderForms.php';
require_once 'SpiderLib/SpiderstrapForms.php';
require_once 'SpiderLib/GUMP.php';

$user = 'root';
$password = '';
$host = 'localhost'; // 127.0.0.1
$database = 'tetris';

/**
 ** Config für Register und Login Pattern in Bootstrap **
 *
 *  Array wird von SpiderstrapForms in login und register getrennt
 *  Es müssen nicht beide definiert werden, jedoch muss der Login 'username' und 'password' als Key enthalten
 *  Außerdem haben alle Felder 'name', 'type', 'id' und 'label'
 *  Diese müssen zumindest mit einem Leerstring '' definiert werden
 * 
 */
$formConf = [
    'login' => [
        'username' => [
            'name' => 'username',
            'type' => 'text',
            'id' => 'username',
            'label' => 'Username',
        ],
        'password' => [
            'name' => 'password',
            'type' => 'password', 
            'id' => 'passwd',
            'label' => 'Passwort'
        ]
    ],
    'register' => [
        'username' => [         
            'name' => 'username',
            'type' => 'text',
            'id' => 'username',
            'label' => 'Username',
        ],
        'email' =>[
            'name' => 'email',
            'type' => 'email',
            'id' => 'mail',
            'label' => 'E-Mail',
        ],
        'password' =>[
            'name' => 'password',
            'type' => 'password',
            'id' => 'passwd',
            'label' => 'Passwort',
        ],
        'passwordConfirm' =>[
            'name' => 'passConfirm',
            'type' => 'password',
            'id' => 'passwdConfirm',
            'label' => 'Password bestätigen',
        ]
    ]
];

// TODO: bester Punkt für Sessionstart? 
session_start();

$db = new SpiderDB($host, $user, $password, $database);
$user = new SpiderUser($db);
$bootstrap = new SpiderstrapForms($formConf);