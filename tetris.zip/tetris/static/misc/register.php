<div class="card">
  <div class="card-body">
    <h5 class="card-title">
          Registrieren
    </h5>
    <?php
    require_once 'misc/check-register.php';

    // $bootstrap ist ein new SpiderstrapForms($formConfig) und in der init vordefiniert
    // Im errorHandlerArray werden die Fehler ausgegeben die von $errors aus der check-login.php ankommen
    // errorHandlerArray ist teil von Spiderstrap und gibt Fehlermeldungen mit Bootstrap-Alert-Class aus
    echo $bootstrap->errorHandlerArray($errors);

    // TODO: Form-Tag des Formulars in die SpiderstrapForms->renderRegister() implementieren
    echo '<form class="px-4 py-3" action="" method="post">'.
    '<div class="form-group">';

    // Rückgabewert von renderRegister ist ein Array
    // ist in der init im Array formConfig vordefiniert
    foreach ($bootstrap->renderRegister() AS $registerField) {
      echo $registerField;
    }
    ?>
  </div>
</div>