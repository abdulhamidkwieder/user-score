<?php

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Tetris - Übersicht</title>
    <link rel="stylesheet" href="https://unpkg.com/purecss@1.0.0/build/pure-min.css" integrity="sha384-nn4HPE8lTHyVtfCBi5yW9d20FjT8BJwUXyWZT9InLYax14RDjBj46LmSztkmNP9w" crossorigin="anonymous">
    <link rel="stylesheet" href="css/layout.css">
</head>
<body>

<div class="container">
    <header class="site-header">
        <h1>Tetris</h1>
    </header> 
    <main>
        <h2>Übersicht</h2>
        <!-- Emmet: ul.pure-menu-list>li.pure-menu-item*3>a.pure-menu-link -->
        <ul class="pure-menu-list">
            <li class="pure-menu-item"><a href="register.php" class="pure-menu-link">Registrierung</a></li>
            <li class="pure-menu-item"><a href="login.php" class="pure-menu-link">Anmelden</a></li>
            <li class="pure-menu-item"><a href="game/tetris/static/" class="pure-menu-link">Game</a></li>
        </ul>
    </main>
</div>

</body>
</html>