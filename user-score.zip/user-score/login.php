<?php
   
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Tetris - Übersicht</title>
    <link rel="stylesheet" href="https://unpkg.com/purecss@1.0.0/build/pure-min.css" integrity="sha384-nn4HPE8lTHyVtfCBi5yW9d20FjT8BJwUXyWZT9InLYax14RDjBj46LmSztkmNP9w" crossorigin="anonymous">
    <link rel="stylesheet" href="css/layout.css">
</head>
<body>

<div class="container">
    <header class="site-header">
        <h1>Tetris</h1>
    </header>
    <main>
        <h2>Anmelden</h2>
        <form action="" method="post" class="pure-form pure-form-stacked">
            <label for="userName">Username</label>
            <input type="text" name="username" id="userName">

            <label for="passWord">Passwort</label>
            <input type="password" name="password" id="passWord">
            <br>
            <input type="submit" value="Anmelden" class="pure-button pure-button-primary">
            <a href="index.php">
                <button type="button" class="pure-button pure-button-primary" >Zurück</button>
            </a>
        </form>
        <label class="form-check-label" for="#">
        <p><a href="password-forgotten.php">Passwort vergessen?</a></p>
        </label>
        
    </main>
</div>

</body>
</html>