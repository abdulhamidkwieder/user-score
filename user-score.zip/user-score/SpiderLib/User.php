<?php
class User {
    protected $db;  // DB Objekt
    protected $id;
    protected $username;
    protected $email;
    protected $isLogged = false;

    public function __construct(SpiderDB $db)
    {
        $this->db = $db;
    }

    public function login()
    {
        # code...
    }

    public function loggedIn() : bool
    {
        # code...
    }

    public function saveScore(int $score)
    {
        # code...
    }

    public function getScore() : int
    {
        # code...
    }

    public function register(string $username, string $password, string $email)
    {
        $sql = <<<SQL
        INSERT INTO user (username, password, email)
        VALUES (?, ?, ?)
SQL;
        $res = $this->db->query($sql, [$username, $password, $email]);
        return $res;
    }



}